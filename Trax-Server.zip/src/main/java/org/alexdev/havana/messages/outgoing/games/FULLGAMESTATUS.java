package org.alexdev.havana.messages.outgoing.games;

import org.alexdev.havana.game.games.Game;
import org.alexdev.havana.game.games.GameManager;
import org.alexdev.havana.game.games.battleball.BattleBallTile;
import org.alexdev.havana.game.games.enums.GameState;
import org.alexdev.havana.game.games.enums.GameType;
import org.alexdev.havana.game.games.snowstorm.SnowStormGame;
import org.alexdev.havana.messages.types.MessageComposer;
import org.alexdev.havana.server.netty.streams.NettyResponse;

public class FULLGAMESTATUS extends MessageComposer {
    private final Game game;

    public FULLGAMESTATUS(Game game) {
        this.game = game;
    }

    @Override
    public void compose(NettyResponse response) {
        if (this.game.getGameType() == GameType.BATTLEBALL) {
            response.writeInt(GameState.STARTED.getStateId());
            response.writeInt(this.game.getPreparingGameSecondsLeft().get());
            response.writeInt(GameManager.getInstance().getPreparingSeconds(game.getGameType()));
            response.writeInt(this.game.getObjects().size()); // TODO: Objects here

            if (this.game.getGameType() == GameType.BATTLEBALL) {
                for (var gameObject : this.game.getObjects()) {
                    response.writeInt(gameObject.getGameObjectType().getObjectId()); // type, 0 = player
                    gameObject.serialiseObject(response);
                }

                response.writeInt(this.game.getRoomModel().getMapSizeY());
                response.writeInt(this.game.getRoomModel().getMapSizeX());

                for (int y = 0; y < this.game.getRoomModel().getMapSizeY(); y++) {
                    for (int x = 0; x < this.game.getRoomModel().getMapSizeX(); x++) {
                        BattleBallTile tile = (BattleBallTile) this.game.getTile(x, y);

                        if (tile == null) {
                            response.writeInt(-1);
                            response.writeInt(0);
                        } else {
                            response.writeInt(tile.getColour().getColourId());
                            response.writeInt(tile.getState().getTileStateId());
                        }
                    }
                }

                response.writeInt(1);
                response.writeInt(0); // TODO: Show events on game load
            }
        }
        else {
            var objects = this.game.getObjects();
            var turns = ((SnowStormGame)this.game).getUpdateTask().getExecutingTurns();

            response.writeInt(this.game.getGameState().getStateId());
            response.writeInt(this.game.getPreparingGameSecondsLeft().get());
            response.writeInt(GameManager.getInstance().getPreparingSeconds(game.getGameType()));
            response.writeInt(this.game.getObjects().size()); // TODO: Objects here

            for (var obj : objects) {
                obj.serialiseObject(response);
            }

            response.writeBool(false);
            response.writeInt(this.game.getTeamAmount());

            new SNOWSTORM_GAMESTATUS(turns).compose(response);
        }
    }

    @Override
    public short getHeader() {
        return 243; // "Cs"
    }
}
