package org.alexdev.havana.server.netty;

public enum ServerHandlerType {
    RC4
}
